import React, { Component } from "react";
import Input from "./Input";
import Button from "./Button";
export class User extends Component {
  render() {
    return <div></div>;
  }
}

export default User;
