import React from "react";

function Button() {
  return <button></button>;
}

export default Button;
