import React, { Component } from "react";
import axios from "axios";

export class UserList extends Component {
  state = { users: [] };
  async componentDidMount() {
    const users = await axios.get(
      "https://61c2fbb19cfb8f0017a3e836.mockapi.io/users"
    );
    this.setState({ users: users.data }, () => {
      console.log(this.state);
    });
  }
  render() {
    return <div></div>;
  }
}

export default UserList;
